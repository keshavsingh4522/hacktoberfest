On mac use the flags "-ll -ly" while compiling and linking
On ubuntu use the flags "-lfl -lm" while compiling and linking