from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import random

class MarsInstaBot():
    def __init__(self, email, password):
        self.browserProfile = webdriver.ChromeOptions()
        self.browserProfile.add_experimental_option('prefs', {'intl.accept_languages': 'en,en_US'})
        self.browser = webdriver.Chrome('chromedriver.exe', chrome_options=self.browserProfile)
        self.email = email
        self.password = password
        
    def signIn(self):
        self.browser.get('https://www.instagram.com/accounts/login/')
        time.sleep(2)

        emailInput = self.browser.find_elements_by_css_selector('form input')[0]
        passwordInput = self.browser.find_elements_by_css_selector('form input')[1]

        emailInput.send_keys(self.email)
        passwordInput.send_keys(self.password)
        passwordInput.send_keys(Keys.ENTER)
        time.sleep(3.505)

    def followUser(self, username):
        self.browser.get('https://www.instagram.com/' + username + '/')
        time.sleep(2)
        try:
            followButton = self.browser.find_element_by_xpath('//button[text() = "Follow"]')
        except:
            try:
                followButton = self.browser.find_element_by_xpath('//button[text() = "Follow Back"]')
            except:
                followButton = 'Zilch'
        if (followButton.text == 'Follow'):
            followButton.click()
            print('Followed user : '+username+'  [Following=False]')
            time.sleep(3)
        elif (followButton.text == 'Follow Back'):
            followButton.click()
            print('Followed user : '+username+'  [Following=True]')
            time.sleep(3)
        else:
            print("You are already following this user")
  

    def unfollowUser(self, username):
        self.browser.get('https://www.instagram.com/' + username + '/')
        time.sleep(2)
        try:
            followButton = self.browser.find_element_by_css_selector("[aria-label=Following]")
            followButton.click()
            time.sleep(2)
            confirmButton = self.browser.find_element_by_xpath('//button[text() = "Unfollow"]')
            confirmButton.click()
            print('Unfollwed user : '+username)
        except():
            print('You are not following the user : '+username)

    def getUserFollowers(self, username, maxima):
        self.browser.get('https://www.instagram.com/' + username)
        followersLink = self.browser.find_element_by_css_selector('ul li a')
        followersLink.click()
        time.sleep(2)
        followersList = self.browser.find_element_by_css_selector('div[role=\'dialog\'] ul')
        numberOfFollowersInList = len(followersList.find_elements_by_css_selector('li'))  
        followersList.click()
        actionChain = webdriver.ActionChains(self.browser)
        while (numberOfFollowersInList < maxima):
            actionChain.key_down(Keys.SPACE).key_up(Keys.SPACE).perform()
            numberOfFollowersInList = len(followersList.find_elements_by_css_selector('li'))
            print(numberOfFollowersInList)
        followers = []
        for user in followersList.find_elements_by_css_selector('li'):
            userLink = user.find_element_by_css_selector('a').get_attribute('href')
            print(userLink)
            followers.append(userLink)
            if (len(followers) == maxima):
                break
        return followers
    
    def getUserFollowing(self, username, maxima=None):
        self.browser.get('https://www.instagram.com/' + username)
        urlTEMP=username+'/following/'
        followingListButton = self.browser.find_element_by_xpath('//a[contains(@href,urlTEMP)]')
        followingListButton.click()
        actionChain = webdriver.ActionChains(self.browser)
        following = []
        

        return following
    def closeBrowser(self):
        self.browser.close()

    def __exit__(self, exc_type, exc_value, traceback):
        self.closeBrowser()
