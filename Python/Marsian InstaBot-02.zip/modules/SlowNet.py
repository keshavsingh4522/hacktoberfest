import random
import time
from core.MarsInstaBot import *
from main import *
pop =   ['instagram','thevjayas','priya.p.varrier','luckydanicer786','dancerukmini',
         'marcosus','marsian_aqua','shraddhakapoor','iam_hemisphere','vanessahudgens',
         'kourtneykardash','krisjenner','kyliejenner','emmawatson','taylorswift',
         'prillylatuconsina96','selenagomez','milliebobbybrown','victoriassecret','paulodybala',
         'dovecameron','whinderssonnunes','marvel','luissuarez9','sunnyleone',
         'louisvuitton','snoopdogg','hudabeauty','justinbieber','dualipa',
         'arianagrande','camila_cabello','k.mbappe','ayutingting92','dishapatani',
         'jlo','fcbarcelona','khloekardashian','lelepons','nike',
         'nasa','hm','nba','buzzfeedtasty','sergioramos',
         'ivetesangalo','marinaruybarbosa','paulpogba','mileycyrus','juventus',
         'justintimberlake','karimbenzema','chrishemsworth','championsleague','caradelevingne',
         'leomessi','jacquelinef143','therock','adidasfootball','jamesrodriguez10',
         '9gag','thenotoriousmma','beyonce','zacefron','manchesterunited',
         'chanelofficial','katyperry','jbalvin','danbilzerian','adidasoriginals',
         'nickyjampr','kendalljenner','daddyyankee','ladygaga','nehakakkar',
         'natgeo','anitta','ronaldinho','nikefootball','badgalriri',
         'priyankachopra','kevinhart4real','premierleague','zara','natgeotravel',
         'garethbale11','hardikpandya93','kartikaaryan','norafatehi','iamsrk',
         'marcelotwelve','5.min.crafts','dior','kimkardashian','realmadrid',
         'akshaykumar','neymarjr','brunamarquezine','colesprouse','martingarrix',
         'chrisbrownofficial','zayn','aliaabhatt','mosaleh','billieeilish',
         'willsmith','gucci','raffinagita1717','cristiano','princessyahrini',
         'deepikapadukone','narendramodi','saraalikhan95','beingsalmankhan','shahidkapoor',
         'katrinakaif','anushkasharma','kritisanon','jannatzubair29','tigerjackieshroff',
         'urvashirautela','rohitsharma45','ananyapanday','mr_faisu_07','varundvn',
         'gururandhawa','amitabhbachchan','rashmika_mandanna','bhuvan.bam22','kapilsharma',
         'avneetkaur_13','parineetichopra','alluarjunonline','ileana_official','sonamkapoor',
         'hedgepooja','thedeverakonda','arishfakhan138','lalalalisa_m','champagnepapi',
         'iamcardib','roses_are_rosie','dannapaola','jennierubyjane','karolg',
         'ddlovato','travisscott','sooyaaa__','real__pcy','postmalone',
         'shakira','blackpinkofficial','baekhyunee_exo','gusttavolima','vanessabryant',
         'eminem','iamhalsey','maluma','chrisbrownofficial','sabrinacarpenter',
         'luisitocomunica','asaprocky','anuel','jacksonwang852g7','elrubiuswtf',
         'tinistoessel','taeyeon_ss','brentrivera','bts.bighitofficial','marsian83',
         ]

def quick_PopRep(username,password,reps=1,delay=420,ifollow=pop,sleeper=180):
    Bot=MarsInstaBot(username,password)
    for times in list(range(0,reps)):
        Bot.signIn()
        random.shuffle(ifollow)
        ifollowed=[]
        for i in ifollow:
            try:
                Bot.followUser(i)
                ifollowed.append(i)
                ifollow.remove(i)
            except():
                customError(0)
                ifollow.remove(i)
        time.sleep(sleeper)
        ifollowed.remove('marsian83')
        for u in ifollowed:
            try:
                Bot.unfollowUser(u)
            except():
                customError(0)
        time.sleep(delay)
        Bot.__exit__()
    return(None)
